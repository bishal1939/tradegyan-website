function toggleDarkMode() {
  document.body.classList.toggle("dark");
}

function logout() {
  localStorage.removeItem("loggedIn");
  window.location.href = "index.html";
}

if (window.location.pathname.includes("learn.html")) {
  fetch("lessons.json")
    .then(res => res.json())
    .then(data => {
      const list = document.getElementById("lessons");
      data.lessons.forEach((lesson, i) => {
        const li = document.createElement("li");
        const key = `lesson_${i}`;
        const isComplete = localStorage.getItem(key) === "true";
        li.innerHTML = `
          <span style="color:${isComplete ? 'green' : 'black'}">${lesson.title}</span>
          <a href="${lesson.resource}" target="_blank" class="btn">Open</a>
          <button onclick="markComplete('${key}', this)" class="btn">${isComplete ? "Completed" : "Mark Complete"}</button>
        `;
        list.appendChild(li);
      });
    });
}

function markComplete(key, btn) {
  localStorage.setItem(key, "true");
  btn.textContent = "Completed";
  btn.style.backgroundColor = "green";
  btn.previousElementSibling.previousElementSibling.style.color = "green";
}